# Testing
JVM unit tests (`gradle testDebugUnitTest`): ScheduleCalcTest (10), ScheduleEngineTest (10), UsageAndFixTest (9), ScreenShareLogicTest (5),
SecurityTest (6), RestrictionTextTest (3). **Status: never run.** The GitHub workflow runs them after the APK build; read the log.
Device tests (`gradle connectedDebugAndroidTest`, needs an emulator or phone, WIPES app data): DeviceBehaviourTest covers persistence,
alarm arming, no-alarm-when-disabled, enforcement-failure reporting without a mechanism, PIN flow and lockout. **Status: never run.**
## Not automated (do by hand)
- Reboot recovery: enable Bedtime to start in 2 min, reboot, open Diagnostics, expect `reconcile:boot`. Same for time-zone change.
- Permission denial/revocation: deny location, deny screen-share consent, revoke Usage Access; each screen must show a clear message, not data.
- Device Owner available: provision a spare/reset phone with the adb command in README, restrict an app, confirm it is suspended and that "Release Device Owner" lifts it.
- Accessibility blocker: enable it, restrict an app, open it, expect Home.
- Network failure / backend: not applicable (no network code exists).
