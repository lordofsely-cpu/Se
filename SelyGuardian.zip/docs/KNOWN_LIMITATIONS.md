# Known limitations
- **Not compiled or run by the author.** Expect compile errors on the first build; none of the tests have been executed.
- **Ordinary phone:** an app cannot reliably block other apps. The Accessibility blocker is best-effort and the device user can turn it off.
  Android 13+ may require "Allow restricted settings" before a sideloaded APK can use Accessibility.
- **Device Owner:** only possible on a phone with no accounts (usually after a reset) and set from a computer with `adb`. Suspended apps show Android's own dialog; a custom message is not guaranteed there.
- **Not tamper-proof:** nothing here makes the app impossible to uninstall or bypass (factory reset, safe mode, ADB, clock changes against the PIN lockout, rooted phones).
- **Reports** are approximate and limited to about a week of Android's retained events.
- **Location** accuracy depends on permission level and the phone; battery saving may pause updates. **Screen capture** may be blank for protected apps and may stop when the screen locks.
- **Package visibility:** only apps with a launcher icon are listed; other apps cannot be selected.
- **No backend:** nothing leaves the phone. Remote features are design notes only.
- Overlap rule is fixed: if either mode is active, restrictions apply (union). Weekend times apply to windows starting Saturday/Sunday.
