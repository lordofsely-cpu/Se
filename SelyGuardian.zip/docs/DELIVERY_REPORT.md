# Sely Guardian — final delivery report (Stage 8)
**Honest headline: the code is written but has never been compiled, run or tested. No APK has been produced.**

1. **Architecture.** Kotlin, Compose Material 3, single activity + navigation, one activity-scoped `GuardianViewModel`.
   `data/` (models, pure schedule maths, SQLite store, usage), `engine/` (reconcile, alarm, receivers, WorkManager), `enforce/` (Device Owner, Accessibility, restriction screen),
   `location/`, `screenshare/`, `security/` (PIN, Keystore, deletion), `ui/`. Everything funnels through `ScheduleManager.reconcile()`.
2. **Implemented (unverified).** See docs/FEATURE_CHECKLIST.md.
3. **Needs extra permissions.** Usage Access (reports), location + notifications (sharing), exact-alarm permission (on-time schedules on Android 13+), Accessibility (fallback blocker), screen-capture consent (each session).
4. **Needs Device Owner.** The strong app suspension. Everything else works on an ordinary phone.
5. **Needs a backend.** Remote administration, remote location, remote screen viewing, sync. None exist.
6. **Incomplete.** Backend and all remote features, signed release build, per-mode app lists, emergency-contact feature, backup/restore. (A 3-step intro with progress bar exists; permissions are explained on each feature screen, not in a setup wizard.)
7. **Test results.** None. 43 JVM tests and 5 device tests exist but have not been run (docs/TESTING.md).
8. **APK path.** None built. After a successful build: `app/build/outputs/apk/debug/app-debug.apk` (also the `SelyGuardian-debug` artifact on GitHub).
9. **Install.** Download the artifact from the GitHub Actions run, unzip, open the APK on the phone, allow "install unknown apps" for your browser/files app.
10. **Device provisioning.** Phone with no accounts, USB debugging on, then from a computer:
    `adb shell dpm set-device-owner com.sely.guardian/.enforce.GuardianAdminReceiver`. Unenroll with Release Device Owner (PIN needed); if the PIN is lost, factory reset.
11. **Android limits.** docs/KNOWN_LIMITATIONS.md.
12. **Future work.** First fix compile errors from the real build; run and fix the tests; test every feature on a phone; then backend (docs/REMOTE_SCREEN_SHARING.md),
    per-mode lists, onboarding wizard, release signing, privacy-policy review (docs/PRIVACY_POLICY_TEMPLATE.md).
