# Sely Guardian — Privacy Policy (TEMPLATE; fill the [brackets] and have it reviewed)
Describes the app as built at Stage 7. Update it if behaviour changes (for example when a backend is added).

**Who is responsible:** [name/contact of the administrator or organization].
**Who it is for:** authorized parental supervision and device management, used openly with the knowledge of the person whose device it is.

## What is stored (only on the device, in the app's private storage)
- Settings: selected restricted/allowed apps, Study and Bedtime schedules.
- An event log: schedule changes, enforcement results, administrator sign-ins and failed attempts, blocked-launch events (app package names). Max ~500 entries.
- The latest location fix, only if location sharing was used. Coordinates are never written to the log.
- The administrator PIN, stored as a salted hash that is also encrypted with a key held in Android Keystore.
## What the app reads (locally, with your permission)
- Installed launcher apps (names, icons). Usage Access: app foreground time (for reports). Location: only while sharing is on.
- Accessibility blocker (optional): only the name of the app that comes to the front. It does not read screen content, typing or passwords.
- Screen sharing: after Android's consent dialog, screen frames are captured at low resolution and discarded. Nothing is saved or sent.
## What is sent off the device
Nothing. There is no account, no backend, no analytics and no network use in this version.
## Visibility and control
Location and screen sharing show a persistent notification and in-app banner, have a Stop control, and never restart by themselves.
## Deleting data
Administrator settings > "Delete history, log and stored location", or "Erase everything and reset". Uninstalling the app also removes its data. Android backup is disabled.
## Limits
A local PIN does not defeat every form of device compromise. Restrictions are not guaranteed to be impossible to bypass.
