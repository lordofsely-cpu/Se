# Feature checklist (honest status)
"Built" = code exists. "Unit" = pure logic covered by JVM tests that have **never been run** (no compiler was available while writing).
"Device" = verified on a real phone: **nothing has been verified on a device yet.**

| Feature | Built | Unit tests | Device-verified | Notes |
|---|---|---|---|---|
| Navigation, theme (light/dark), 3-step welcome with progress | yes | – | no | |
| Dashboard live status | yes | – | no | |
| App discovery, search, categories, restrict/allow | yes | categorizer: no | no | launcher apps only (package-visibility rules) |
| Study / Bedtime settings, persistence | yes | schedule maths, codec | no | one global app list shared by both |
| Schedule engine (alarm, boot/time-zone recovery, WorkManager net) | yes | next-transition, DST, overlap | no | exact alarm needs permission on Android 13+ |
| Device Owner enforcement (suspend + verify + release) | yes | – | no | needs adb provisioning on a reset phone |
| Accessibility blocker (fallback) | yes | – | no | best-effort; can be switched off |
| Restriction screen | yes | message text | no | system dialog is shown for suspended apps |
| Screen-time reports | yes | usage maths | no | approximate |
| Location sharing (local only) | yes | fix codec | no | foreground service, never auto-resumes |
| Screen sharing capture (no remote viewing) | yes | geometry, throttle | no | frames discarded |
| Admin PIN, lockout, session, gating | yes | hash, rules, lockout, session | no | |
| Health check, audit log, deletion, reset | yes | – | no | |
| Remote administration / backend | **no** | – | – | not built |
| Remote viewing / remote location | **no** | – | – | not built |
| Signed release build | **no** | – | – | debug APK only |
