@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.sely.guardian.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.sely.guardian.data.AppCategory
import com.sely.guardian.ui.GuardianViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun AppIcon(pkg: String) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, pkg) {
        value = withContext(Dispatchers.IO) {
            runCatching { ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
        }
    }
    bmp?.let { Image(it, null, Modifier.size(40.dp)) } ?: Spacer(Modifier.size(40.dp))
}

@Composable
fun AppsScreen(vm: GuardianViewModel) {
    val apps by vm.apps.collectAsState()
    val loading by vm.loading.collectAsState()
    val sel by vm.selection.collectAsState()
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<AppCategory?>(null) }
    val shown = remember(apps, query, cat) { apps.filter { (cat == null || it.category == cat) && it.name.contains(query, true) } }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Apps", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 16.dp))
        Text("${sel.restricted.size} restricted · ${sel.allowed.size} allowed. Blocking only happens once an enforcement mechanism is set up (Dashboard > Protection).",
            style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(query, { query = it }, label = { Text("Search") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(cat == null, { cat = null }, { Text("All") })
            AppCategory.values().forEach { c -> FilterChip(cat == c, { cat = c }, { Text(c.label) }) }
        }
        when {
            loading -> Text("Loading apps…")
            shown.isEmpty() -> Text("No apps found. Android only shows apps with a launcher icon that this app is allowed to see.")
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.pkg }) { a ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AppIcon(a.pkg)
                    Column {
                        Text(a.name, style = MaterialTheme.typography.titleSmall)
                        Text(a.category.label, style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            val r = a.pkg in sel.restricted
                            val al = a.pkg in sel.allowed
                            FilterChip(r, { vm.setRestricted(a.pkg, !r) }, { Text("Restrict") })
                            FilterChip(al, { vm.setAllowed(a.pkg, !al) }, { Text("Allow") })
                        }
                    }
                }
            }
        }
    }
}
