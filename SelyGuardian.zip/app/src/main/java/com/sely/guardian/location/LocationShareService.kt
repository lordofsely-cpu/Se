package com.sely.guardian.location

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.content.ContextCompat
import com.sely.guardian.MainActivity
import com.sely.guardian.data.GuardianDb
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

data class Fix(val lat: Double, val lon: Double, val accuracyM: Float, val timeMs: Long, val provider: String)

object FixCodec {
    fun encode(f: Fix) = "${f.lat}|${f.lon}|${f.accuracyM}|${f.timeMs}|${f.provider}"
    fun decode(s: String?): Fix? = try {
        val p = s!!.split("|"); Fix(p[0].toDouble(), p[1].toDouble(), p[2].toFloat(), p[3].toLong(), p[4])
    } catch (e: Exception) { null }
}

data class LocationUiState(
    val active: Boolean = false, val intervalSec: Int = 300, val fix: Fix? = null,
    val lastUpdateMs: Long? = null, val message: String? = null,
)

/** In-memory only: "active" is never persisted, so a restart can never silently resume sharing. */
object LocationState { val flow = MutableStateFlow(LocationUiState()) }

object LocationControl {
    fun start(ctx: Context, intervalSec: Int) = ContextCompat.startForegroundService(
        ctx, Intent(ctx, LocationShareService::class.java).putExtra(LocationShareService.EXTRA_INTERVAL, intervalSec))
    fun stop(ctx: Context) { ctx.stopService(Intent(ctx, LocationShareService::class.java)) }
}

/** Visible foreground service (ongoing notification with a Stop action). Local only: no remote transmission exists yet. */
class LocationShareService : Service() {
    private lateinit var lm: LocationManager
    private val listener = object : LocationListener {
        override fun onLocationChanged(l: Location) = handle(l)
        @Deprecated("Deprecated in Java") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
        override fun onProviderEnabled(p: String) {}
        override fun onProviderDisabled(p: String) {}
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val interval = i?.getIntExtra(EXTRA_INTERVAL, 300) ?: 300
        try { startInForeground() } catch (e: Exception) { fail("Could not start the visible sharing notification (${e.javaClass.simpleName})"); return START_NOT_STICKY }
        startUpdates(interval)
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Location sharing", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 2, Intent(this, LocationShareService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setContentTitle("Sely Guardian: location sharing is ON")
            .setContentText("Tap to open. Use Stop to end sharing.")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation).setOngoing(true).setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION) else startForeground(ID, n)
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun startUpdates(intervalSec: Int) {
        val fine = granted(Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = granted(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (!fine && !coarse) { fail("Location permission is missing."); return }
        val providers = buildList {
            if (fine && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) add(LocationManager.GPS_PROVIDER)
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) add(LocationManager.NETWORK_PROVIDER)
        }
        if (providers.isEmpty()) { fail("Device location is turned off or unavailable. Turn it on in system settings."); return }
        try {
            providers.forEach { lm.requestLocationUpdates(it, intervalSec * 1000L, 0f, listener, Looper.getMainLooper()) }
            LocationState.flow.update { it.copy(active = true, intervalSec = intervalSec, message = null) }
            providers.forEach { p -> lm.getLastKnownLocation(p)?.let { l -> handle(l) } }
        } catch (e: SecurityException) { fail("Android refused location access.") }
    }

    private fun handle(l: Location) {
        val f = Fix(l.latitude, l.longitude, l.accuracy, l.time, l.provider ?: "unknown")
        GuardianDb.of(this).put("loc_last", FixCodec.encode(f))   // latest fix only; coordinates are never written to the log
        LocationState.flow.update { it.copy(fix = f, lastUpdateMs = System.currentTimeMillis()) }
    }

    private fun fail(msg: String) {
        LocationState.flow.update { it.copy(active = false, message = msg) }
        stopSelf()
    }

    override fun onDestroy() {
        if (::lm.isInitialized) try { lm.removeUpdates(listener) } catch (_: Exception) { }
        LocationState.flow.update { it.copy(active = false) }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_INTERVAL = "interval"
        const val ACTION_STOP = "com.sely.guardian.LOCATION_STOP"
        private const val CH = "location_sharing"
        private const val ID = 4201
    }
}
