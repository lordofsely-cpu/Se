package com.sely.guardian.data

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process
import java.time.LocalDate
import java.time.ZoneId

class UsageRepository(private val ctx: Context) {
    @Suppress("DEPRECATION")
    fun hasAccess(): Boolean {
        val ao = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        else ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun events(begin: Long, end: Long): List<UsageEvent> {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val q = usm.queryEvents(begin, end)
        val e = UsageEvents.Event()
        val out = mutableListOf<UsageEvent>()
        while (q.hasNextEvent()) {
            q.getNextEvent(e)
            if (e.eventType == UsageCalc.RESUMED || e.eventType == UsageCalc.PAUSED)
                out += UsageEvent(e.packageName, e.className ?: "", e.eventType, e.timeStamp)
        }
        return out
    }

    private fun label(pkg: String) = runCatching {
        val pm = ctx.packageManager; pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString()
    }.getOrDefault(pkg)

    fun loadReport(): UsageReport {
        if (!hasAccess()) return UsageReport.NONE
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        fun ms(d: LocalDate) = d.atStartOfDay(zone).toInstant().toEpochMilli()
        val now = System.currentTimeMillis()
        val weekStartDate = today.minusDays(6)
        val sessions = UsageCalc.sessions(events(ms(weekStartDate), now), ms(weekStartDate), now).filter { it.pkg != ctx.packageName }
        fun top(m: Map<String, Long>) = m.entries.sortedByDescending { it.value }.take(10).map { AppUsage(it.key, label(it.key), it.value) }
        val daily = (0..6).map { i ->
            val d = weekStartDate.plusDays(i.toLong())
            d to UsageCalc.totals(sessions, ms(d), minOf(ms(d.plusDays(1)), now)).values.sum()
        }
        val todayT = UsageCalc.totals(sessions, ms(today), now)
        val weekT = UsageCalc.totals(sessions, ms(weekStartDate), now)
        return UsageReport(true, todayT.values.sum(), top(todayT), weekT.values.sum(), top(weekT), daily)
    }
}
