@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.sely.guardian.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.sely.guardian.data.ScheduleCalc
import com.sely.guardian.enforce.Enforcement
import com.sely.guardian.enforce.Mechanism
import com.sely.guardian.location.LocationState
import com.sely.guardian.security.AuthRepository
import com.sely.guardian.screenshare.ScreenShareState
import com.sely.guardian.ui.Feature
import com.sely.guardian.ui.GuardianViewModel
import com.sely.guardian.ui.features
import java.time.LocalDateTime

@Composable
fun WelcomeScreen(onContinue: () -> Unit) {
    val steps = listOf(
        "Purpose" to "Sely Guardian helps a parent or authorized administrator set Study and Bedtime schedules, restrict chosen apps, see screen time, and (only with visible consent) share location or screen. It is meant to be used openly, with the knowledge of the person whose phone it is.",
        "Privacy" to "Everything stays on this phone: no account, no network use, no analytics. Location and screen sharing show a notification and a Stop button and never start by themselves. You can delete all data in Admin at any time.",
        "Setup" to "Next: 1) set an administrator PIN (Dashboard > Administrator). 2) Pick restricted apps. 3) Set Study/Bedtime times. 4) Choose how apps get blocked under Dashboard > Protection (Device Owner or the Accessibility blocker). Until step 4, nothing is blocked. Permissions are asked only when you use the feature that needs them.",
    )
    var step by androidx.compose.runtime.remember { androidx.compose.runtime.mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)) {
        Text("SELY GUARDIAN", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
        Text("Designed by Kingsley", style = MaterialTheme.typography.labelMedium)
        LinearProgressIndicator(progress = { (step + 1) / steps.size.toFloat() }, modifier = Modifier.fillMaxWidth())
        Text("Step ${step + 1} of ${steps.size}: ${steps[step].first}", style = MaterialTheme.typography.titleMedium)
        Text(steps[step].second)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (step > 0) OutlinedButton(onClick = { step-- }) { Text("Back") }
            Button(onClick = { if (step < steps.size - 1) step++ else onContinue() }) { Text(if (step < steps.size - 1) "Next" else "Get started") }
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String, alert: Boolean = false, onClick: (() -> Unit)? = null) {
    val content: @Composable ColumnScope.() -> Unit = {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(body, style = MaterialTheme.typography.bodyMedium,
                color = if (alert) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
        }
    }
    if (onClick != null) Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), content = content)
    else Card(modifier = Modifier.fillMaxWidth(), content = content)
}

@Composable
fun DashboardScreen(vm: GuardianViewModel, onOpen: (String) -> Unit) {
    val study by vm.study.collectAsState()
    val bed by vm.bedtime.collectAsState()
    val sel by vm.selection.collectAsState()
    val now = LocalDateTime.now()
    val ctx = LocalContext.current
    val mech = Enforcement.mechanism(ctx)
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Dashboard", style = MaterialTheme.typography.headlineMedium) }
        item {
            InfoCard("Protection", "Mechanism: ${mech.label}" + if (mech == Mechanism.NONE) ". NOTHING IS BLOCKED. Tap to set up." else ". Tap for details.",
                alert = mech == Mechanism.NONE, onClick = { onOpen("enforcement") })
        }
        item { InfoCard("Study Mode", ScheduleCalc.state(study, now).label, onClick = { onOpen("study") }) }
        item { InfoCard("Bedtime Mode", ScheduleCalc.state(bed, now).label, onClick = { onOpen("bedtime") }) }
        item { InfoCard("Restricted apps", "${sel.restricted.size} restricted · ${sel.allowed.size} allowed", onClick = { onOpen("apps") }) }
        item { InfoCard("Screen time", "Needs Usage Access. Tap to view reports and history.", onClick = { onOpen("reports") }) }
        item {
            val loc by LocationState.flow.collectAsState()
            InfoCard("Location sharing", if (loc.active) "ACTIVE every ${loc.intervalSec / 60} min (local only)" else "Off",
                alert = loc.active, onClick = { onOpen("location") })
        }
        item {
            val shr by ScreenShareState.flow.collectAsState()
            InfoCard("Screen sharing", if (shr.active) "ACTIVE (capture only, nothing sent)" else "Off", alert = shr.active, onClick = { onOpen("screen") })
        }
        item { InfoCard("Schedule diagnostics", "Alarm status and execution log", onClick = { onOpen("diagnostics") }) }
        item { InfoCard("Last sync", "Never (no backend yet)") }
        item { InfoCard("Recent security events", "None recorded (event log arrives in Stage 7)") }
        item {
            InfoCard("Administrator", if (AuthRepository(ctx).hasPin()) "PIN set. Changes need the PIN." else "No PIN yet. Tap to set one (required to change settings).",
                alert = !AuthRepository(ctx).hasPin(), onClick = { onOpen("admin") })
        }
    }
}

@Composable
fun FeatureStubScreen(f: Feature) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text(f.title, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("Status: ${f.status.label} (planned for stage ${f.stage})")
        Text(f.note, style = MaterialTheme.typography.bodySmall)
    }
}
