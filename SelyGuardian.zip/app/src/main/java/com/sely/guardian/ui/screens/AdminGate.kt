@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.sely.guardian.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.sely.guardian.security.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Wraps a screen: needs a PIN to exist, and an unlocked session (5 min of inactivity locks it again). */
@Composable
fun AdminGate(allowSetup: Boolean, onGoAdmin: () -> Unit, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val auth = remember { AuthRepository(ctx) }
    val scope = rememberCoroutineScope()
    var hasPin by remember { mutableStateOf(auth.hasPin()) }
    var unlocked by remember { mutableStateOf(AdminSession.isUnlocked(System.currentTimeMillis())) }
    LaunchedEffect(unlocked) {
        while (unlocked) { delay(1000); if (!AdminSession.isUnlocked(System.currentTimeMillis())) unlocked = false }
    }
    when {
        !hasPin && allowSetup -> PinSetup { pin ->
            scope.launch {
                withContext(Dispatchers.Default) { auth.setPin(pin) }
                AdminSession.unlock(System.currentTimeMillis()); hasPin = true; unlocked = true
            }
        }
        !hasPin -> Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)) {
            Text("Set an administrator PIN first", style = MaterialTheme.typography.titleLarge)
            Text("Settings can only be changed by an authenticated administrator.")
            Button(onClick = onGoAdmin) { Text("Set PIN") }
        }
        !unlocked -> PinEntry(auth) { unlocked = true }
        else -> Box(Modifier.fillMaxSize().pointerInput(Unit) {
            awaitPointerEventScope { while (true) { awaitPointerEvent(PointerEventPass.Initial); AdminSession.touch(System.currentTimeMillis()) } }
        }) { content() }
    }
}

@Composable
fun PinSetup(onSet: (String) -> Unit) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)) {
        Text("Create administrator PIN", style = MaterialTheme.typography.titleLarge)
        Text("4 to 8 digits. If you forget it there is no recovery except erasing the app data (see Admin guidance).", style = MaterialTheme.typography.bodySmall)
        PinField("New PIN", a) { a = it }
        PinField("Repeat PIN", b) { b = it }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(onClick = {
            err = PinHasher.validate(a) ?: if (a != b) "The two PINs do not match." else null
            if (err == null) onSet(a)
        }) { Text("Set PIN") }
    }
}

@Composable
fun PinField(label: String, value: String, enabled: Boolean = true, onChange: (String) -> Unit) {
    OutlinedTextField(value, { if (it.length <= 8 && it.all(Char::isDigit)) onChange(it) }, label = { Text(label) }, singleLine = true, enabled = enabled,
        visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
}

@Composable
fun PinEntry(auth: AuthRepository, onOk: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var remain by remember { mutableStateOf(auth.lockedRemainingMs(System.currentTimeMillis())) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(remain > 0) { while (remain > 0) { delay(1000); remain = auth.lockedRemainingMs(System.currentTimeMillis()) } }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)) {
        Text("Administrator PIN", style = MaterialTheme.typography.titleLarge)
        PinField("PIN", pin, enabled = remain <= 0) { pin = it }
        if (remain > 0) Text("Too many wrong attempts. Try again in ${remain / 1000 + 1}s.", color = MaterialTheme.colorScheme.error)
        msg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(enabled = remain <= 0 && pin.length >= 4, onClick = {
            val entered = pin
            scope.launch {
                val r = withContext(Dispatchers.Default) { auth.verify(entered, System.currentTimeMillis()) }
                pin = ""
                val now = System.currentTimeMillis()
                when (r) {
                    is VerifyResult.Ok -> { AdminSession.unlock(now); onOk() }
                    is VerifyResult.Wrong -> { msg = "Wrong PIN."; remain = auth.lockedRemainingMs(now) }
                    is VerifyResult.Locked -> remain = r.ms
                    is VerifyResult.Error -> msg = r.msg
                    is VerifyResult.NoPin -> msg = "No PIN is set."
                }
            }
        }) { Text("Unlock") }
    }
}
