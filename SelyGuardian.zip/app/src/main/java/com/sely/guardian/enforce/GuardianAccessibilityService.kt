package com.sely.guardian.enforce

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import com.sely.guardian.data.Codec
import com.sely.guardian.data.GuardianDb

/**
 * Opt-in fallback. Reads ONLY the package name of the window that came to the front (canRetrieveWindowContent=false).
 * If it is on the current restricted list: press Home and try to show the restriction screen. Best-effort only:
 * the device user can disable this service in Settings, and Android may block the screen launch.
 */
class GuardianAccessibilityService : AccessibilityService() {
    private var blocked: Set<String> = emptySet()
    private var lastLoad = 0L
    private var lastBlock = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        val now = SystemClock.elapsedRealtime()
        val db = GuardianDb.of(this)
        if (now - lastLoad > 3000) { blocked = Codec.decodeSet(db.get("a11y_blocked")); lastLoad = now }
        if (pkg == packageName || pkg !in blocked) return
        performGlobalAction(GLOBAL_ACTION_HOME)
        try {
            startActivity(Intent(this, RestrictionActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("pkg", pkg))
        } catch (ex: Exception) {
            db.log("a11y", "restriction_screen_failed", ex.javaClass.simpleName)
        }
        if (now - lastBlock > 2000) { db.log("a11y", "blocked_launch", pkg); lastBlock = now }
    }

    override fun onInterrupt() {}
}
