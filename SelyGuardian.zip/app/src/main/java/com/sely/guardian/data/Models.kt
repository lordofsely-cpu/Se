package com.sely.guardian.data

enum class AppCategory(val label: String) {
    GAMES("Games"), SOCIAL("Social media"), ENTERTAINMENT("Entertainment"), EDUCATION("Education"), OTHER("Other")
}

data class AppEntry(val pkg: String, val name: String, val category: AppCategory)

/** Minutes since midnight. If startMin > endMin the window crosses midnight (e.g. 22:00-07:00). */
data class TimeRange(val startMin: Int, val endMin: Int)

fun fmtMin(m: Int) = "%02d:%02d".format(m / 60, m % 60)

/** Days use java.time.DayOfWeek.value (1 = Monday ... 7 = Sunday). */
data class ModeConfig(
    val enabled: Boolean = false,
    val days: Set<Int> = (1..7).toSet(),
    val window: TimeRange,
    val weekendWindow: TimeRange? = null,
    val breaks: List<TimeRange> = emptyList(),
)

/** Global selection used by both modes (per-mode lists are a possible later change). */
data class AppSelection(val restricted: Set<String> = emptySet(), val allowed: Set<String> = emptySet())

object Defaults {
    val study = ModeConfig(days = (1..5).toSet(), window = TimeRange(16 * 60, 18 * 60))
    val bedtime = ModeConfig(window = TimeRange(22 * 60, 7 * 60))
}
