package com.sely.guardian.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo

object Categorizer {
    fun categorize(pkg: String, sysCategory: Int): AppCategory {
        when (sysCategory) {
            ApplicationInfo.CATEGORY_GAME -> return AppCategory.GAMES
            ApplicationInfo.CATEGORY_SOCIAL -> return AppCategory.SOCIAL
            ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_IMAGE -> return AppCategory.ENTERTAINMENT
        }
        val p = pkg.lowercase()
        fun has(vararg k: String) = k.any { p.contains(it) }
        return when {
            has("facebook", "instagram", "whatsapp", "tiktok", "snapchat", "twitter", "telegram", "reddit", "discord") -> AppCategory.SOCIAL
            has("youtube", "netflix", "spotify", "twitch", "primevideo", "disney") -> AppCategory.ENTERTAINMENT
            has("classroom", "duolingo", "khan", "coursera", "udemy", "edu", "quizlet") -> AppCategory.EDUCATION
            has("game", "gaming", "supercell", "roblox", "minecraft") -> AppCategory.GAMES
            else -> AppCategory.OTHER
        }
    }
}

/** Discovers launchable apps via the <queries> MAIN/LAUNCHER declaration (no QUERY_ALL_PACKAGES). */
class AppRepository(private val ctx: Context) {
    @Suppress("DEPRECATION")
    fun loadLaunchableApps(): List<AppEntry> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map {
                val ai = it.activityInfo
                AppEntry(ai.packageName, it.loadLabel(pm).toString(), Categorizer.categorize(ai.packageName, ai.applicationInfo.category))
            }
            .distinctBy { it.pkg }
            .sortedBy { it.name.lowercase() }
    }
}
