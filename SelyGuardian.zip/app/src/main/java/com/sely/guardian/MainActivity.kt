package com.sely.guardian

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.sely.guardian.ui.AppNav
import com.sely.guardian.ui.theme.SelyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SelyTheme { AppNav() } }
    }
}
