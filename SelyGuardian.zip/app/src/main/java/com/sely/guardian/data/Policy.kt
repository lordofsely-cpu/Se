package com.sely.guardian.data

data class ResolvedPolicy(val activeModes: List<String>, val restricted: Set<String>)

data class EnforcementReport(val enforced: Boolean, val message: String)

/** Seam for Stage 4 (Device Owner / fallback mechanisms). */
interface Enforcer { fun apply(policy: ResolvedPolicy): EnforcementReport }

object NoEnforcer : Enforcer {
    override fun apply(policy: ResolvedPolicy) = EnforcementReport(false, "no enforcement mechanism implemented yet (Stage 4)")
}

/**
 * Overlap rule: if EITHER mode is in an active window (not on break), restrictions apply.
 * Restricted = selected restricted apps minus allowed apps. A Study break never lifts an active Bedtime restriction.
 */
object PolicyResolver {
    fun resolve(study: ScheduleState, bedtime: ScheduleState, sel: AppSelection): ResolvedPolicy {
        val modes = buildList {
            if (study == ScheduleState.ACTIVE) add("study")
            if (bedtime == ScheduleState.ACTIVE) add("bedtime")
        }
        return ResolvedPolicy(modes, if (modes.isEmpty()) emptySet() else sel.restricted - sel.allowed)
    }
}

object RestrictionText {
    fun modeName(studyState: String?, bedtimeState: String?) = when {
        bedtimeState == "ACTIVE" -> "Bedtime Mode"
        studyState == "ACTIVE" -> "Study Mode"
        else -> "a scheduled mode"
    }
    fun lines(mode: String) = listOf(
        "SELY GUARDIAN",
        "This application is restricted during $mode.",
        "Please return to your scheduled activities.",
        "Managed by your authorized administrator.",
    )
}
