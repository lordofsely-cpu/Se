@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.sely.guardian.ui.screens

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.sely.guardian.screenshare.ScreenShareControl
import com.sely.guardian.screenshare.ScreenShareState
import kotlinx.coroutines.flow.update
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val f = DateTimeFormatter.ofPattern("HH:mm:ss")
private fun t(ms: Long) = f.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))

@Composable
fun ScreenShareScreen() {
    val ctx = LocalContext.current
    val st by ScreenShareState.flow.collectAsState()
    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == Activity.RESULT_OK && d != null) ScreenShareControl.start(ctx, r.resultCode, d)
        else ScreenShareState.flow.update { it.copy(message = "Screen sharing consent was denied. Nothing was captured.") }
    }
    val mpm = remember { ctx.getSystemService(MediaProjectionManager::class.java) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { consent.launch(mpm.createScreenCaptureIntent()) }
    val notifOff = Build.VERSION.SDK_INT >= 33 &&
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Screen sharing", style = MaterialTheme.typography.headlineMedium)
        if (st.active) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Column(Modifier.padding(12.dp)) {
                    Text("SCREEN SHARING IS ACTIVE", style = MaterialTheme.typography.titleMedium)
                    Text("Capturing ${st.width}×${st.height}, about 2 frames per second.")
                    Text("Frames captured: ${st.frames}" + (st.lastFrameMs?.let { " · last at ${t(it)}" } ?: ""))
                    Text("Destination: ${st.sink}", style = MaterialTheme.typography.bodySmall)
                }
            }
            Button(onClick = { ScreenShareControl.stop(ctx) }) { Text("Stop sharing") }
        } else {
            Text("Sharing is OFF.")
            Button(onClick = {
                if (notifOff) notif.launch(Manifest.permission.POST_NOTIFICATIONS) else consent.launch(mpm.createScreenCaptureIntent())
            }) { Text("Start sharing") }
        }
        st.message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (notifOff) Text("Notification permission is off, so the sharing notification will not appear in the shade. This banner still shows.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)

        Text("What this does", style = MaterialTheme.typography.titleMedium)
        Text("Android shows its own permission dialog every time, and a persistent notification (plus Android's own indicator) stays visible while sharing. " +
            "It stops when you press Stop here, Stop in the notification, Android's own stop control, or if Android ends the permission. It never restarts by itself.")
        Text("Remote viewing is NOT built: no backend exists. For now frames are captured at low resolution to prove the capture pipeline works, then discarded. Nothing is stored or sent. " +
            "Protected content (some banking or video apps) may appear blank. Android may stop capture when the screen is locked.",
            style = MaterialTheme.typography.bodySmall)
    }
}
