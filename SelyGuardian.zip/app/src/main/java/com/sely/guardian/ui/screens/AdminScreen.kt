@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.sely.guardian.ui.screens

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.sely.guardian.data.GuardianDb
import com.sely.guardian.data.LogRow
import com.sely.guardian.data.UsageRepository
import com.sely.guardian.enforce.Enforcement
import com.sely.guardian.enforce.Mechanism
import com.sely.guardian.security.*
import com.sely.guardian.ui.GuardianViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private data class Health(val name: String, val ok: Boolean, val detail: String)

private fun health(ctx: Context): List<Health> {
    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    fun granted(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    val mech = Enforcement.mechanism(ctx)
    return listOf(
        Health("Usage Access", UsageRepository(ctx).hasAccess(), "Needed for screen-time reports"),
        Health("Location permission", granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION), "Needed only for location sharing"),
        Health("Notifications", Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS), "Shows the sharing indicators"),
        Health("Exact alarms", Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms(), "Lets schedules switch on time"),
        Health("Enforcement mechanism", mech != Mechanism.NONE, mech.label),
    )
}

private val tsFmt = DateTimeFormatter.ofPattern("MMM d HH:mm")

@Composable
fun AdminScreen(vm: GuardianViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val auth = remember { AuthRepository(ctx) }
    var tick by remember { mutableStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }
    val items = remember(tick) { health(ctx) }
    val audit by produceState(emptyList<LogRow>(), tick) {
        value = withContext(Dispatchers.IO) {
            GuardianDb.of(ctx).recentLogWhere(listOf("pin_set", "unlock", "unlock_failed", "data_deleted", "data_reset", "device_owner_released"), 25)
        }
    }
    var cur by remember { mutableStateOf("") }
    var n1 by remember { mutableStateOf("") }
    var n2 by remember { mutableStateOf("") }
    var pinMsg by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Administrator settings", style = MaterialTheme.typography.headlineMedium)
        OutlinedButton(onClick = { AdminSession.lock() }) { Text("Lock now") }
        Text("The session locks by itself after 5 minutes without touching the screen.", style = MaterialTheme.typography.bodySmall)

        Text("Change PIN", style = MaterialTheme.typography.titleMedium)
        PinField("Current PIN", cur) { cur = it }
        PinField("New PIN", n1) { n1 = it }
        PinField("Repeat new PIN", n2) { n2 = it }
        pinMsg?.let { Text(it) }
        Button(onClick = {
            val err = PinHasher.validate(n1) ?: if (n1 != n2) "The new PINs do not match." else null
            if (err != null) { pinMsg = err; return@Button }
            val c = cur; val n = n1
            scope.launch {
                val r = withContext(Dispatchers.Default) { auth.verify(c, System.currentTimeMillis()) }
                if (r is VerifyResult.Ok) { withContext(Dispatchers.Default) { auth.setPin(n) }; pinMsg = "PIN changed." }
                else pinMsg = "Current PIN was not accepted."
                cur = ""; n1 = ""; n2 = ""
            }
        }) { Text("Change PIN") }

        Text("Permission and device health", style = MaterialTheme.typography.titleMedium)
        items.forEach { h ->
            Text((if (h.ok) "OK  " else "MISSING  ") + h.name + " — " + h.detail,
                color = if (h.ok) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        Text("Device management: " + if (Enforcement.isDeviceOwner(ctx)) "this app IS Device Owner" else "not Device Owner (ordinary device)", style = MaterialTheme.typography.bodySmall)

        Text("Privacy and data", style = MaterialTheme.typography.titleMedium)
        Text("Everything stays on this phone. No account, no network traffic, no analytics. Stored: your settings, the event log, the latest location (only if you used sharing) and the encrypted PIN.",
            style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = { confirm = "history" }) { Text("Delete history, log and stored location") }
        OutlinedButton(onClick = { confirm = "reset" }) { Text("Erase everything and reset") }

        Text("Backup and recovery", style = MaterialTheme.typography.titleMedium)
        Text("Settings are not backed up (Android backup is switched off). Forgotten PIN: there is no recovery by design; clearing the app's data (Android Settings > Apps) resets it. " +
            "If this app is Device Owner, use Release Device Owner (Enforcement screen) before that; if the PIN is lost, a factory reset is the guaranteed way out.",
            style = MaterialTheme.typography.bodySmall)

        Text("Security note", style = MaterialTheme.typography.titleMedium)
        Text("A local PIN does not protect against every kind of device-level compromise (a rooted phone, physical access to a computer with debugging enabled, a factory reset, or uninstalling the app on an ordinary device). " +
            "Lockout timing relies on the phone's clock, which the phone's user could change.", style = MaterialTheme.typography.bodySmall)

        Text("Diagnostic information", style = MaterialTheme.typography.titleMedium)
        val ver = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull()
        Text("App ${ver ?: "?"} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MANUFACTURER} ${Build.MODEL}", style = MaterialTheme.typography.bodySmall)

        Text("Administrator audit log", style = MaterialTheme.typography.titleMedium)
        if (audit.isEmpty()) Text("No entries.", style = MaterialTheme.typography.bodySmall)
        audit.forEach { Text("${tsFmt.format(Instant.ofEpochMilli(it.ts).atZone(ZoneId.systemDefault()))}  ${it.event}: ${it.detail}", style = MaterialTheme.typography.bodySmall) }
    }
    confirm?.let { kind ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(if (kind == "reset") "Erase everything?" else "Delete history?") },
            text = { Text(if (kind == "reset") "Schedules, selections, log, location and the PIN are erased and any app restrictions are lifted. Device Owner status is not removed."
                          else "The log and stored location are deleted. Settings and PIN stay.") },
            confirmButton = { TextButton(onClick = { if (kind == "reset") vm.resetAll() else vm.deleteHistory(); confirm = null }) { Text("Confirm") } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } },
        )
    }
}
