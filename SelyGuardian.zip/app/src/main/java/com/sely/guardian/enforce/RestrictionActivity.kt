@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.sely.guardian.enforce

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sely.guardian.data.GuardianDb
import com.sely.guardian.data.RestrictionText
import com.sely.guardian.ui.theme.SelyTheme

class RestrictionActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra("pkg") ?: intent.getStringExtra(Intent.EXTRA_PACKAGE_NAME)
        val db = GuardianDb.of(this)
        val mode = RestrictionText.modeName(db.get("last_state_study"), db.get("last_state_bedtime"))
        val label = pkg?.let { runCatching { packageManager.getApplicationInfo(it, 0).loadLabel(packageManager).toString() }.getOrNull() }
        val lines = RestrictionText.lines(mode)
        setContent {
            SelyTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.padding(32.dp), verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(lines[0], style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                        label?.let { Text(it, style = MaterialTheme.typography.titleMedium) }
                        lines.drop(1).forEach { Text(it) }
                        Button(onClick = { finish() }) { Text("OK") }
                    }
                }
            }
        }
    }
}
