package com.sely.guardian.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class LogRow(val ts: Long, val mode: String, val event: String, val detail: String)

/** Small SQLite store (no annotation processor needed): key/value config plus an execution log. Logs never hold secrets. */
class GuardianDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "guardian.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE kv(k TEXT PRIMARY KEY, v TEXT NOT NULL)")
        db.execSQL("CREATE TABLE exec_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, mode TEXT NOT NULL, event TEXT NOT NULL, detail TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun get(k: String): String? =
        readableDatabase.rawQuery("SELECT v FROM kv WHERE k=?", arrayOf(k)).use { if (it.moveToFirst()) it.getString(0) else null }

    fun put(k: String, v: String) {
        val cv = ContentValues().apply { put("k", k); put("v", v) }
        writableDatabase.insertWithOnConflict("kv", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun log(mode: String, event: String, detail: String) {
        val d = writableDatabase
        val cv = ContentValues().apply { put("ts", System.currentTimeMillis()); put("mode", mode); put("event", event); put("detail", detail) }
        d.insert("exec_log", null, cv)
        d.execSQL("DELETE FROM exec_log WHERE id <= (SELECT MAX(id) FROM exec_log) - 500")
    }

    fun clearLog() { writableDatabase.execSQL("DELETE FROM exec_log") }
    fun clearAll() { writableDatabase.execSQL("DELETE FROM exec_log"); writableDatabase.execSQL("DELETE FROM kv") }

    fun delete(k: String) { writableDatabase.delete("kv", "k=?", arrayOf(k)) }

    fun recentLogWhere(events: List<String>, limit: Int): List<LogRow> {
        val ph = events.joinToString(",") { "?" }
        return readableDatabase.rawQuery("SELECT ts, mode, event, detail FROM exec_log WHERE event IN ($ph) ORDER BY id DESC LIMIT ?",
            (events + limit.toString()).toTypedArray()).use { c ->
            buildList { while (c.moveToNext()) add(LogRow(c.getLong(0), c.getString(1), c.getString(2), c.getString(3))) }
        }
    }

    fun recentLog(limit: Int): List<LogRow> =
        readableDatabase.rawQuery("SELECT ts, mode, event, detail FROM exec_log ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
            buildList { while (c.moveToNext()) add(LogRow(c.getLong(0), c.getString(1), c.getString(2), c.getString(3))) }
        }

    companion object {
        @Volatile private var inst: GuardianDb? = null
        fun of(ctx: Context): GuardianDb = inst ?: synchronized(this) { inst ?: GuardianDb(ctx.applicationContext).also { inst = it } }
    }
}
