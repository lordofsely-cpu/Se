@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.sely.guardian.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sely.guardian.ui.screens.*

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("dashboard", "Home", Icons.Default.Home),
    Tab("apps", "Apps", Icons.Default.Menu),
    Tab("study", "Study", Icons.Default.DateRange),
    Tab("bedtime", "Bedtime", Icons.Default.Notifications),
    Tab("admin", "Admin", Icons.Default.Settings),
)

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val vm: GuardianViewModel = viewModel()
    val route by nav.currentBackStackEntryAsState()
    val current = route?.destination?.route
    Scaffold(bottomBar = {
        if (current != null && current != "welcome") NavigationBar {
            tabs.forEach { t ->
                NavigationBarItem(
                    selected = current == t.route,
                    onClick = {
                        nav.navigate(t.route) {
                            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true; restoreState = true
                        }
                    },
                    icon = { Icon(t.icon, t.label) }, label = { Text(t.label) })
            }
        }
    }) { pad ->
        val Gate: @Composable (Boolean, @Composable () -> Unit) -> Unit = { setup, content ->
            AdminGate(setup, { nav.navigate("admin") }, content)
        }
        NavHost(nav, "welcome", Modifier.padding(pad)) {
            composable("welcome") {
                WelcomeScreen { nav.navigate("dashboard") { popUpTo("welcome") { inclusive = true } } }
            }
            composable("dashboard") { DashboardScreen(vm) { nav.navigate(it) } }
            composable("apps") { Gate(false) { AppsScreen(vm) } }
            composable("reports") { Gate(false) { ReportsScreen(vm) } }
            composable("screen") { Gate(false) { ScreenShareScreen() } }
            composable("location") { Gate(false) { LocationScreen(vm) } }
            composable("enforcement") { Gate(false) { EnforcementScreen(vm) } }
            composable("diagnostics") { Gate(false) { DiagnosticsScreen(vm) } }
            composable("admin") { Gate(true) { AdminScreen(vm) } }
            composable("study") {
                val c by vm.study.collectAsState(); val sel by vm.selection.collectAsState()
                Gate(false) { ModeScreen("Study Mode", c, sel, true, false, { vm.updateStudy(it) }) { nav.navigate("apps") } }
            }
            composable("bedtime") {
                val c by vm.bedtime.collectAsState(); val sel by vm.selection.collectAsState()
                Gate(false) { ModeScreen("Bedtime Mode", c, sel, false, true, { vm.updateBedtime(it) }) { nav.navigate("apps") } }
            }
        }
    }
}
