package com.sely.guardian.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.sely.guardian.data.Codec
import com.sely.guardian.data.GuardianDb
import com.sely.guardian.enforce.Enforcement
import com.sely.guardian.engine.ScheduleManager
import com.sely.guardian.location.LocationControl
import com.sely.guardian.location.LocationState
import com.sely.guardian.screenshare.ScreenShareControl
import kotlinx.coroutines.flow.update
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec

object PinHasher {
    fun newSalt(): ByteArray = ByteArray(16).also { SecureRandom().nextBytes(it) }
    fun hash(pin: String, salt: ByteArray, iterations: Int = 120_000): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(pin.toCharArray(), salt, iterations, 256)).encoded
    fun verify(pin: String, salt: ByteArray, expected: ByteArray) = MessageDigest.isEqual(hash(pin, salt), expected)

    /** Returns an error message, or null if acceptable. */
    fun validate(pin: String): String? = when {
        pin.length !in 4..8 || !pin.all { it.isDigit() } -> "Use 4 to 8 digits."
        pin.toSet().size == 1 -> "Choose a PIN that is not all the same digit."
        else -> null
    }
}

object LockoutPolicy {
    fun delayMs(failures: Int): Long = when {
        failures < 5 -> 0
        failures == 5 -> 30_000
        failures == 6 -> 60_000
        failures == 7 -> 300_000
        else -> 900_000
    }
}

class SessionState(private val timeoutMs: Long = 5 * 60_000L) {
    @Volatile private var until = 0L
    fun unlock(now: Long) { until = now + timeoutMs }
    fun touch(now: Long) { if (now < until) until = now + timeoutMs }
    fun isUnlocked(now: Long) = now < until
    fun lock() { until = 0 }
}
val AdminSession = SessionState()

sealed class VerifyResult {
    object Ok : VerifyResult()
    object NoPin : VerifyResult()
    data class Locked(val ms: Long) : VerifyResult()
    data class Wrong(val failures: Int, val lockMs: Long) : VerifyResult()
    data class Error(val msg: String) : VerifyResult()
}

/** AES-256-GCM key that lives in Android Keystore and never leaves it. */
object KeystoreCrypto {
    private const val ALIAS = "sely_admin_key"
    private fun store() = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    private fun key(): SecretKey {
        (store().getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
        return g.generateKey()
    }
    fun encrypt(plain: ByteArray): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key())
        return Base64.encodeToString(c.iv + c.doFinal(plain), Base64.NO_WRAP)
    }
    fun decrypt(s: String): ByteArray {
        val all = Base64.decode(s, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
        return c.doFinal(all, 12, all.size - 12)
    }
    fun deleteKey() { try { store().deleteEntry(ALIAS) } catch (_: Exception) { } }
}

/** PIN = PBKDF2 hash with random salt, then encrypted with the Keystore key before it is stored. Audit events never contain the PIN. */
class AuthRepository(ctx: Context) {
    private val db = GuardianDb.of(ctx)
    fun hasPin() = db.get("admin_pin") != null
    fun lockedRemainingMs(now: Long) = maxOf(0L, (db.get("pin_locked_until")?.toLongOrNull() ?: 0L) - now)

    fun setPin(pin: String) {
        val salt = PinHasher.newSalt()
        db.put("admin_pin", KeystoreCrypto.encrypt(salt + PinHasher.hash(pin, salt)))
        db.put("pin_failures", "0"); db.put("pin_locked_until", "0")
        db.log("admin", "pin_set", "administrator PIN created or changed")
    }

    fun verify(pin: String, now: Long): VerifyResult {
        val rem = lockedRemainingMs(now)
        if (rem > 0) return VerifyResult.Locked(rem)
        val stored = db.get("admin_pin") ?: return VerifyResult.NoPin
        val blob = try { KeystoreCrypto.decrypt(stored) } catch (e: Exception) {
            return VerifyResult.Error("The stored PIN could not be read. Reset the app data to start over.")
        }
        if (PinHasher.verify(pin, blob.copyOfRange(0, 16), blob.copyOfRange(16, blob.size))) {
            db.put("pin_failures", "0"); db.log("admin", "unlock", "administrator unlocked")
            return VerifyResult.Ok
        }
        val f = (db.get("pin_failures")?.toIntOrNull() ?: 0) + 1
        db.put("pin_failures", f.toString())
        val d = LockoutPolicy.delayMs(f)
        if (d > 0) db.put("pin_locked_until", (now + d).toString())
        db.log("admin", "unlock_failed", "wrong PIN, attempt $f")
        return VerifyResult.Wrong(f, d)
    }
}

object DataDeletion {
    private fun stopSharing(ctx: Context) { LocationControl.stop(ctx); ScreenShareControl.stop(ctx) }

    fun deleteHistory(ctx: Context) {
        val db = GuardianDb.of(ctx)
        stopSharing(ctx)
        db.clearLog(); db.delete("loc_last")
        LocationState.flow.update { it.copy(fix = null, lastUpdateMs = null) }
        db.log("admin", "data_deleted", "history, log and stored location deleted")
    }

    /** Lifts Device Owner suspensions first, then wipes ALL app data including the PIN. Does not remove Device Owner status. */
    fun resetAll(ctx: Context) {
        val db = GuardianDb.of(ctx)
        stopSharing(ctx)
        if (Enforcement.isDeviceOwner(ctx)) {
            val set = Codec.decodeSet(db.get("suspended_pkgs"))
            if (set.isNotEmpty()) try { Enforcement.dpm(ctx).setPackagesSuspended(Enforcement.admin(ctx), set.toTypedArray(), false) } catch (_: Exception) { }
        }
        db.clearAll(); KeystoreCrypto.deleteKey(); AdminSession.lock()
        LocationState.flow.update { it.copy(fix = null, lastUpdateMs = null) }
        try { ScheduleManager(ctx).reconcile("reset") } catch (_: Exception) { }
        db.log("admin", "data_reset", "all app data and the PIN were erased")
    }
}
