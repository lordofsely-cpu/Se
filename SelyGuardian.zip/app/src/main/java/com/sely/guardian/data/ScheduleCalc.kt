package com.sely.guardian.data

import java.time.LocalDateTime

enum class ScheduleState(val label: String) {
    DISABLED("Disabled"), OUTSIDE("Outside scheduled window"),
    ACTIVE("Inside scheduled window"), ON_BREAK("On scheduled break")
}

/**
 * Pure schedule logic. An overnight window belongs to the day it STARTS on:
 * a Monday 22:00-07:00 window runs until Tuesday 07:00 even if Tuesday is not selected.
 * The weekend window (if set) applies to windows that start on Saturday or Sunday.
 */
object ScheduleCalc {
    private fun windowFor(c: ModeConfig, d: java.time.DayOfWeek): TimeRange =
        if (c.weekendWindow != null && (d == java.time.DayOfWeek.SATURDAY || d == java.time.DayOfWeek.SUNDAY))
            c.weekendWindow else c.window

    private fun startsToday(w: TimeRange, m: Int) = when {
        w.startMin < w.endMin -> m >= w.startMin && m < w.endMin
        w.startMin > w.endMin -> m >= w.startMin
        else -> false
    }

    private fun spillsFromYesterday(w: TimeRange, m: Int) = w.startMin > w.endMin && m < w.endMin

    fun state(c: ModeConfig, now: LocalDateTime): ScheduleState {
        if (!c.enabled) return ScheduleState.DISABLED
        val m = now.hour * 60 + now.minute
        val today = now.dayOfWeek
        val yesterday = today.minus(1)
        val inWindow = (today.value in c.days && startsToday(windowFor(c, today), m)) ||
            (yesterday.value in c.days && spillsFromYesterday(windowFor(c, yesterday), m))
        if (!inWindow) return ScheduleState.OUTSIDE
        if (c.breaks.any { it.startMin < it.endMin && m >= it.startMin && m < it.endMin }) return ScheduleState.ON_BREAK
        return ScheduleState.ACTIVE
    }

    fun validate(c: ModeConfig): List<String> {
        val e = mutableListOf<String>()
        if (c.days.isEmpty()) e += "Select at least one day."
        if (c.window.startMin == c.window.endMin) e += "Start and end time must differ."
        if (c.weekendWindow?.let { it.startMin == it.endMin } == true) e += "Weekend start and end time must differ."
        if (c.breaks.any { it.startMin >= it.endMin }) e += "Each break must end after it starts (no breaks across midnight)."
        return e
    }
}

data class Transition(val at: java.time.LocalDateTime, val to: ScheduleState)

/** Next wall-clock moment at which the state differs from the state at [now]; null if none within 9 days. */
fun ScheduleCalc.nextTransition(c: ModeConfig, now: LocalDateTime): Transition? {
    if (!c.enabled) return null
    val nowMin = now.truncatedTo(java.time.temporal.ChronoUnit.MINUTES)
    val current = state(c, nowMin)
    val mins = (listOf(c.window.startMin, c.window.endMin) +
        (c.weekendWindow?.let { listOf(it.startMin, it.endMin) } ?: emptyList()) +
        c.breaks.flatMap { listOf(it.startMin, it.endMin) }).distinct().sorted()
    for (d in 0..8) {
        val date = nowMin.toLocalDate().plusDays(d.toLong())
        for (m in mins) {
            val t = date.atTime(m / 60, m % 60)
            if (!t.isAfter(nowMin)) continue
            val s = state(c, t)
            if (s != current) return Transition(t, s)
        }
    }
    return null
}

/** DST gaps shift forward; overlaps use the earlier offset. The engine re-reconciles on every alarm so drift self-corrects. */
fun ScheduleCalc.toMillis(t: LocalDateTime, zone: java.time.ZoneId): Long = t.atZone(zone).toInstant().toEpochMilli()
