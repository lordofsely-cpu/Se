package com.sely.guardian

import com.sely.guardian.data.*
import com.sely.guardian.data.ScheduleState.*
import org.junit.Assert.*
import org.junit.Test
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId

class ScheduleEngineTest {
    private fun at(day: Int, h: Int, m: Int = 0) = LocalDateTime.of(2026, 11, day, h, m) // Nov 2 2026 = Monday
    private val study = ModeConfig(true, (1..5).toSet(), TimeRange(960, 1080))
    private val bed = ModeConfig(true, (1..7).toSet(), TimeRange(1320, 420))

    @Test fun nextEndOfStudy() = assertEquals(Transition(at(2, 18), OUTSIDE), ScheduleCalc.nextTransition(study, at(2, 17)))
    @Test fun nextStartAfterWeekend() = assertEquals(Transition(at(9, 16), ACTIVE), ScheduleCalc.nextTransition(study, at(6, 18, 30)))
    @Test fun breakIsATransition() {
        val c = study.copy(breaks = listOf(TimeRange(1050, 1065)))
        assertEquals(Transition(at(2, 17, 30), ON_BREAK), ScheduleCalc.nextTransition(c, at(2, 17)))
        assertEquals(Transition(at(2, 17, 45), ACTIVE), ScheduleCalc.nextTransition(c, at(2, 17, 30)))
    }
    @Test fun disabledOrInvalidHasNoTransition() {
        assertNull(ScheduleCalc.nextTransition(study.copy(enabled = false), at(2, 17)))
        assertNull(ScheduleCalc.nextTransition(study.copy(days = emptySet()), at(2, 17)))
    }
    @Test fun overnightNextTransition() = assertEquals(Transition(at(3, 7), OUTSIDE), ScheduleCalc.nextTransition(bed, at(2, 23)))

    @Test fun dstEndNextTransitionElapsedTime() {
        val ny = ZoneId.of("America/New_York")
        val now = LocalDateTime.of(2026, 10, 31, 23, 0)          // DST ends Nov 1 2026
        val t = ScheduleCalc.nextTransition(bed, now)!!
        assertEquals(LocalDateTime.of(2026, 11, 1, 7, 0), t.at)
        val elapsed = ScheduleCalc.toMillis(t.at, ny) - ScheduleCalc.toMillis(now, ny)
        assertEquals(Duration.ofHours(9).toMillis(), elapsed)      // 8 wall hours + the repeated hour
    }

    private val sel = AppSelection(setOf("a", "b"), setOf("b"))
    @Test fun noActiveModeMeansNoRestrictions() = assertTrue(PolicyResolver.resolve(OUTSIDE, ON_BREAK, sel).restricted.isEmpty())
    @Test fun allowedAppsAreExcluded() = assertEquals(setOf("a"), PolicyResolver.resolve(ACTIVE, OUTSIDE, sel).restricted)
    @Test fun overlapIsUnion() = assertEquals(listOf("study", "bedtime"), PolicyResolver.resolve(ACTIVE, ACTIVE, sel).activeModes)
    @Test fun studyBreakDoesNotLiftBedtime() {
        val p = PolicyResolver.resolve(ON_BREAK, ACTIVE, sel)
        assertEquals(listOf("bedtime"), p.activeModes); assertEquals(setOf("a"), p.restricted)
    }
}
