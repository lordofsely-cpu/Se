package com.sely.guardian

import com.sely.guardian.security.*
import org.junit.Assert.*
import org.junit.Test

class SecurityTest {
    @Test fun hashVerifies() {
        val salt = PinHasher.newSalt(); val h = PinHasher.hash("482915", salt)
        assertTrue(PinHasher.verify("482915", salt, h)); assertFalse(PinHasher.verify("482916", salt, h))
    }
    @Test fun differentSaltsGiveDifferentHashes() =
        assertFalse(PinHasher.hash("482915", PinHasher.newSalt()).contentEquals(PinHasher.hash("482915", PinHasher.newSalt())))
    @Test fun pinRules() {
        assertNull(PinHasher.validate("4829")); assertNotNull(PinHasher.validate("123")); assertNotNull(PinHasher.validate("123456789"))
        assertNotNull(PinHasher.validate("12a4")); assertNotNull(PinHasher.validate("1111"))
    }
    @Test fun lockoutEscalates() {
        assertEquals(0L, LockoutPolicy.delayMs(4)); assertEquals(30_000L, LockoutPolicy.delayMs(5))
        assertEquals(300_000L, LockoutPolicy.delayMs(7)); assertEquals(900_000L, LockoutPolicy.delayMs(20))
    }
    @Test fun sessionTimesOutAndTouchExtends() {
        val s = SessionState(1000)
        assertFalse(s.isUnlocked(0)); s.unlock(0)
        assertTrue(s.isUnlocked(999)); assertFalse(s.isUnlocked(1000))
        s.touch(900); assertTrue(s.isUnlocked(1800))
        s.lock(); assertFalse(s.isUnlocked(1))
    }
    @Test fun touchCannotReviveExpiredSession() { val s = SessionState(1000); s.unlock(0); s.touch(5000); assertFalse(s.isUnlocked(5001)) }
}
