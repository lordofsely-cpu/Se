package com.sely.guardian

import com.sely.guardian.data.*
import com.sely.guardian.data.UsageCalc.PAUSED
import com.sely.guardian.data.UsageCalc.RESUMED
import com.sely.guardian.location.Fix
import com.sely.guardian.location.FixCodec
import org.junit.Assert.*
import org.junit.Test

class UsageAndFixTest {
    private fun ev(p: String, t: Int, time: Long, c: String = "A") = UsageEvent(p, c, t, time)

    @Test fun simpleSession() {
        val s = UsageCalc.sessions(listOf(ev("x", RESUMED, 100), ev("x", PAUSED, 400)), 0, 1000)
        assertEquals(listOf(Session("x", 100, 400)), s)
    }
    @Test fun orphanPauseStartsAtRangeStart() =
        assertEquals(listOf(Session("x", 50, 200)), UsageCalc.sessions(listOf(ev("x", PAUSED, 200)), 50, 1000))
    @Test fun openSessionClosesAtRangeEnd() =
        assertEquals(listOf(Session("x", 700, 1000)), UsageCalc.sessions(listOf(ev("x", RESUMED, 700)), 0, 1000))
    @Test fun missedPauseClosesEarlierSession() {
        val s = UsageCalc.sessions(listOf(ev("x", RESUMED, 100), ev("x", RESUMED, 300), ev("x", PAUSED, 500)), 0, 1000)
        assertEquals(400L, UsageCalc.totals(s, 0, 1000)["x"])
    }
    @Test fun totalsClipToWindowAndSplitAcrossMidnight() {
        val s = listOf(Session("x", 900, 1100))
        assertEquals(100L, UsageCalc.totals(s, 0, 1000)["x"])
        assertEquals(100L, UsageCalc.totals(s, 1000, 2000)["x"])
        assertNull(UsageCalc.totals(s, 1200, 2000)["x"])
    }
    @Test fun separateActivitiesSumPerPackage() {
        val s = UsageCalc.sessions(listOf(ev("x", RESUMED, 0, "A"), ev("x", PAUSED, 100, "A"), ev("x", RESUMED, 100, "B"), ev("x", PAUSED, 250, "B")), 0, 1000)
        assertEquals(250L, UsageCalc.totals(s, 0, 1000)["x"])
    }
    @Test fun durationFormat() {
        assertEquals("2h 05m", UsageCalc.fmtDuration(125 * 60_000L))
        assertEquals("7m", UsageCalc.fmtDuration(7 * 60_000L))
        assertEquals("<1m", UsageCalc.fmtDuration(20_000L))
    }
    @Test fun fixRoundTrip() {
        val f = Fix(6.52431, 3.37921, 12.5f, 1_700_000_000_000L, "gps")
        assertEquals(f, FixCodec.decode(FixCodec.encode(f)))
    }
    @Test fun badFixIsNull() { assertNull(FixCodec.decode("junk")); assertNull(FixCodec.decode(null)) }
}
