package com.sely.guardian

import com.sely.guardian.data.*
import com.sely.guardian.data.ScheduleState.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDateTime

class ScheduleCalcTest {
    // 2026-11-02 is a Monday
    private fun at(day: Int, h: Int, m: Int = 0) = LocalDateTime.of(2026, 11, day, h, m)
    private val study = ModeConfig(true, (1..5).toSet(), TimeRange(960, 1080))
    private val bed = ModeConfig(true, (1..7).toSet(), TimeRange(1320, 420))

    @Test fun studyWindowBoundaries() {
        assertEquals(ACTIVE, ScheduleCalc.state(study, at(2, 17)))
        assertEquals(OUTSIDE, ScheduleCalc.state(study, at(2, 18)))   // end is exclusive
        assertEquals(OUTSIDE, ScheduleCalc.state(study, at(7, 17)))   // Saturday
    }
    @Test fun studyBreak() = assertEquals(ON_BREAK, ScheduleCalc.state(study.copy(breaks = listOf(TimeRange(1020, 1035))), at(2, 17, 5)))
    @Test fun disabled() = assertEquals(DISABLED, ScheduleCalc.state(study.copy(enabled = false), at(2, 17)))
    @Test fun overnightBothSides() {
        assertEquals(ACTIVE, ScheduleCalc.state(bed, at(2, 23)))
        assertEquals(ACTIVE, ScheduleCalc.state(bed, at(3, 6, 59)))
        assertEquals(OUTSIDE, ScheduleCalc.state(bed, at(3, 7)))
    }
    @Test fun overnightBelongsToStartDay() {
        val monOnly = bed.copy(days = setOf(1))
        assertEquals(ACTIVE, ScheduleCalc.state(monOnly, at(3, 6)))
        assertEquals(OUTSIDE, ScheduleCalc.state(monOnly, at(3, 23)))
        assertEquals(OUTSIDE, ScheduleCalc.state(monOnly, at(2, 6)))
    }
    @Test fun weekendWindow() {
        val c = bed.copy(weekendWindow = TimeRange(1410, 540)) // 23:30-09:00 for Sat/Sun starts
        assertEquals(ACTIVE, ScheduleCalc.state(c, at(6, 23)))      // Fri uses weekday window
        assertEquals(OUTSIDE, ScheduleCalc.state(c, at(7, 23)))     // Sat 23:00 before 23:30
        assertEquals(ACTIVE, ScheduleCalc.state(c, at(7, 23, 45)))
        assertEquals(ACTIVE, ScheduleCalc.state(c, at(8, 8)))       // Sun morning spill
    }
    @Test fun validation() {
        assertTrue(ScheduleCalc.validate(study).isEmpty())
        assertEquals(2, ScheduleCalc.validate(study.copy(days = emptySet(), window = TimeRange(600, 600))).size)
    }
    @Test fun codecRoundTrip() {
        val c = ModeConfig(true, setOf(1, 3, 7), TimeRange(60, 120), TimeRange(30, 40), listOf(TimeRange(1, 2), TimeRange(3, 4)))
        assertEquals(c, Codec.decode(Codec.encode(c), Defaults.study))
        val noExtras = Defaults.bedtime
        assertEquals(noExtras, Codec.decode(Codec.encode(noExtras), Defaults.study))
    }
    @Test fun corruptStorageFallsBackToDefault() = assertEquals(Defaults.study, Codec.decode("garbage", Defaults.study))
    @Test fun setCodec() = assertEquals(setOf("a.b", "c.d"), Codec.decodeSet(Codec.encodeSet(setOf("c.d", "a.b"))))
}
