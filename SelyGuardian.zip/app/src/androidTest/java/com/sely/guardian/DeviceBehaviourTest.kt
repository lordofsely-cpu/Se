package com.sely.guardian

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.sely.guardian.data.*
import com.sely.guardian.enforce.CompositeEnforcer
import com.sely.guardian.enforce.Enforcement
import com.sely.guardian.enforce.Mechanism
import com.sely.guardian.engine.ScheduleManager
import com.sely.guardian.security.AuthRepository
import com.sely.guardian.security.KeystoreCrypto
import com.sely.guardian.security.VerifyResult
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Run on a device/emulator: `gradle connectedDebugAndroidTest`. WARNING: wipes this app's data first. */
@RunWith(AndroidJUnit4::class)
class DeviceBehaviourTest {
    private val ctx: Context get() = ApplicationProvider.getApplicationContext()

    @Before fun clean() { GuardianDb.of(ctx).clearAll(); KeystoreCrypto.deleteKey() }

    @Test fun configSurvivesNewStoreInstance() {
        val c = ModeConfig(true, setOf(1, 2), TimeRange(60, 120), breaks = listOf(TimeRange(70, 80)))
        SettingsStore(ctx).saveMode("study", c)
        assertEquals(c, SettingsStore(ctx).loadMode("study", Defaults.study))
    }

    @Test fun reconcileLogsAndArmsAlarm() {
        SettingsStore(ctx).saveMode("bedtime", Defaults.bedtime.copy(enabled = true))
        val m = ScheduleManager(ctx)
        m.reconcile("test")
        val d = m.diagnostics()
        assertNotNull(d.nextAtMillis)
        assertTrue(d.log.any { it.event == "reconcile:test" })
    }

    @Test fun nothingEnabledMeansNoAlarm() {
        val m = ScheduleManager(ctx)
        m.reconcile("test")
        assertNull(m.diagnostics().nextAtMillis)
    }

    @Test fun enforcementFailureIsReportedHonestlyWithoutAMechanism() {
        assumeTrue(Enforcement.mechanism(ctx) == Mechanism.NONE)   // device is not Device Owner and the blocker is off
        val r = CompositeEnforcer(ctx).apply(ResolvedPolicy(listOf("study"), setOf("com.example.app")))
        assertFalse(r.enforced)
        assertTrue(r.message.contains("NOT ENFORCED"))
    }

    @Test fun pinFlowAndLockout() {
        val a = AuthRepository(ctx)
        assertFalse(a.hasPin())
        a.setPin("482915")
        val now = System.currentTimeMillis()
        assertTrue(a.verify("482915", now) is VerifyResult.Ok)
        repeat(5) { assertTrue(a.verify("000012", now) is VerifyResult.Wrong) }
        assertTrue(a.verify("482915", now) is VerifyResult.Locked)
    }
}
