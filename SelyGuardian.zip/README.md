# Sely Guardian (Designed by Kingsley)
Android parental-control / device-management app. **Status: all 8 stages written; never compiled, run or tested.**
Read docs/DELIVERY_REPORT.md first, then docs/FEATURE_CHECKLIST.md and docs/KNOWN_LIMITATIONS.md.

## Build
- GitHub: put the zip (or the project) in the repo, use the provided workflow; it builds `SelyGuardian-debug` and runs unit tests.
- Android Studio: open the folder, Build > Build APK(s). CLI: `gradle assembleDebug` (wrapper JAR not included; run `gradle wrapper --gradle-version 8.7` once).
- Output: `app/build/outputs/apk/debug/app-debug.apk`. Unit tests: `gradle testDebugUnitTest`. Device tests: `gradle connectedDebugAndroidTest`.

## First run
Open the app, set the administrator PIN (Dashboard > Administrator), choose restricted apps, set Study/Bedtime, then Dashboard > Protection to set up enforcement.
Without Device Owner or the Accessibility blocker nothing is blocked, and the app says so.

## Design rules
Overlap: either mode active means restrictions apply. Overnight windows belong to the day they start. Weekend times apply to windows starting Sat/Sun.
State changes are logged when detected. Location and screen sharing are visible, stoppable and never auto-resume. No data leaves the device.
Details of each mechanism: docs/. Manual test list: docs/TESTING.md.
